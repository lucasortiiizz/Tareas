class Docente {
    constructor(id, apellido, nombre, mail, cumple, celular) {
        this.docente_id = id;
        this.docente_apellido = apellido;
        this.docente_nombre = nombre;
        this.docente_mail = mail;
        this.docente_cumple = cumple;
        this.docente_celular = celular;
    }
}
