class Docentes {
    constructor() {
        let data = localStorage.getItem('docentes');
        if (!data) {
            this.datos = [];
        } else {
            this.datos = JSON.parse(data);
        }
    }

    getMaxId() {
        let idmax = 0;
        this.datos.forEach(d => {
            if (!isNaN(d.docente_id) && d.docente_id > idmax) { // Verifica si el ID no es NaN
                idmax = d.docente_id;
            }
        });
        return idmax;
    }

    agregar(docente) {
        docente.docente_id = this.getMaxId() + 1;
        this.datos.push(docente);
        this.persistir();
    }

    actualizar(docente) {
        const index = this.datos.findIndex(d => d.docente_id === docente.docente_id);
        if (index !== -1) {
            this.datos[index] = docente;
            this.persistir();
        }
    }

    borrar(id) {
        this.datos = this.datos.filter(docente => docente.docente_id !== id);
        this.persistir();
    }

    obtenerPorId(id) {
        return this.datos.find(docente => docente.docente_id === id);
    }

    persistir() {
        localStorage.setItem('docentes', JSON.stringify(this.datos));
    }
}
