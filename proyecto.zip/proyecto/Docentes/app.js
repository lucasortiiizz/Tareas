document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('docenteForm');
    const tableBody = document.getElementById('docentesTable');
    const cancelButton = document.getElementById('cancelar');

    const docentes = new Docentes(); 

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        const id = parseInt(document.getElementById('docente_id').value) || 0;
        const apellido = document.getElementById('docente_apellido').value;
        const nombre = document.getElementById('docente_nombre').value;
        const mail = document.getElementById('docente_mail').value;
        const cumple = document.getElementById('docente_cumple').value;
        const celular = document.getElementById('docente_celular').value;

        const docente = new Docente(id, apellido, nombre, mail, cumple, celular);

        if (id === -1) {
            docentes.agregar(docente); 
            console.log("Se agregó un nuevo docente:", docente);
        } else {
            docentes.actualizar(docente); 
            console.log("Se actualizó el docente:", docente);
        }

        limpiarFormulario();
        dibujarTabla();
        console.log("Se actualizó la tabla");
    });

    cancelButton.addEventListener('click', function () {
        console.log("Limpiando Formulario");
        limpiarFormulario();
    });

    function limpiarFormulario() {
        console.log("Limpiando Formulario");
        form.reset();
        document.getElementById('docente_id').value = -1;
    }

    function dibujarTabla() {
        console.log("Dibujando Tabla");
        let html = '';
        docentes.datos.forEach(docente => {
            html += `
                <tr>
                    <td>${docente.docente_id}</td>
                    <td>${docente.docente_apellido}</td>
                    <td>${docente.docente_nombre}</td>
                    <td>${docente.docente_mail}</td>
                    <td>${docente.docente_cumple}</td>
                    <td>${docente.docente_celular}</td>
                    <td>
                        <button class="btn btn-info btn-sm editar" data-id="${docente.docente_id}">Editar</button>
                        <button class="btn btn-danger btn-sm borrar" data-id="${docente.docente_id}">Eliminar</button>
                    </td>
                </tr>
            `;
        });
        tableBody.innerHTML = html;
    
        asignarEventos();
    }
    

    function asignarEventos() {
        console.log("Asignando Eventos");
        const editarBotones = document.querySelectorAll('.editar');
        editarBotones.forEach(boton => {
            boton.addEventListener('click', function (event) {
                console.log("Editando Docente");
                const id = parseInt(event.target.getAttribute('data-id'));
                const docente = docentes.obtenerPorId(id);
                if (docente) {
                    document.getElementById('docente_id').value = docente.docente_id;
                    document.getElementById('docente_apellido').value = docente.docente_apellido;
                    document.getElementById('docente_nombre').value = docente.docente_nombre;
                    document.getElementById('docente_mail').value = docente.docente_mail;
                    document.getElementById('docente_cumple').value = docente.docente_cumple;
                    document.getElementById('docente_celular').value = docente.docente_celular;
                }
            });
        });

        const borrarBotones = document.querySelectorAll('.borrar');
        borrarBotones.forEach(boton => {
            boton.addEventListener('click', function (event) {
                console.log("Eliminando Docente");
                const id = parseInt(event.target.getAttribute('data-id'));
                docentes.borrar(id);
                dibujarTabla();
                console.log("Se eliminó el docente con ID:", id);
            });
        });
    }
    
    dibujarTabla();
});
